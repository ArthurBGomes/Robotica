
class SensoresCor{

};
